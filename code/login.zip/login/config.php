<?php
$host = "localhost";
$user = "root";
$password = "";
$datbase = "testdb";

mysql_connect($host,$user,$password);
mysql_select_db($datbase);
?>