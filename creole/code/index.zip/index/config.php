<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "interview";
$con = mysql_connect($host,$user,$password,$database);	
?>